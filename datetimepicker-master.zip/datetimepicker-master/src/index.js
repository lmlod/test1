/**
 * @format
 * @flow strict-local
 */
import RNDateTimePicker from './datetimepicker';
export * from './eventCreators';
export {DateTimePickerAndroid} from './DateTimePickerAndroid';

export default RNDateTimePicker;
