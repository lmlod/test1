/**
 * Custom state to store frameSize that the component descriptor will use to modify the
 * shadow node layout.
 */

#include "RNDateTimePickerState.h"

namespace facebook {
namespace react {

} // namespace react
} // namespace facebook