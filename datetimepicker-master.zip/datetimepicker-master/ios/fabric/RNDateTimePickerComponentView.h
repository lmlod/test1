/**
 * RNDateTimePickerComponentView is only be available when fabric is enabled.
 */

#import <React/RCTViewComponentView.h>

NS_ASSUME_NONNULL_BEGIN

@interface RNDateTimePickerComponentView : RCTViewComponentView

@end

NS_ASSUME_NONNULL_END
